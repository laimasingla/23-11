package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.CreditCardTransaction;
import com.cg.cardmanagement.model.DebitCardTransaction;
import com.cg.cardmanagement.service.BankService;

@RestController
@RequestMapping("/banker")
public class BankController {

	@Autowired
	private BankService bankService;

	@GetMapping(value = "/viewNewdebit")
	public ResponseEntity<List<CaseIdBean>> listNewDebitQueries() throws IBSException {

		List<CaseIdBean> caseBeans = bankService.viewNewDebitQueries();
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@GetMapping("/viewDebitmismatch")
	public ResponseEntity<List<CaseIdBean>> debitMismatch() throws IBSException {

		List<CaseIdBean> caseBeans = bankService.viewDebitMismatchQueries();
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@GetMapping("/viewCreditmismatch")
	public ResponseEntity<List<CaseIdBean>> creditMismatch() throws IBSException {

		List<CaseIdBean> caseBeans = bankService.viewCreditMismatchQueries();
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@GetMapping("/debitQueriesMismatch/{serviceRequest}")
	public ResponseEntity<DebitCardTransaction> replyDebitQueriesMismatch(
			@PathVariable("serviceRequest") String serviceRequest) throws IBSException {

		BigInteger mismatchTransactionId = bankService.getDebitTransactionId(serviceRequest);
		DebitCardTransaction debitCardBeanTrns = bankService.getDebitMismatchTransaction(mismatchTransactionId);
		return new ResponseEntity<DebitCardTransaction>(debitCardBeanTrns, HttpStatus.OK);

	}

	@GetMapping("/creditQueriesMismatch/{serviceRequest}")
	public ResponseEntity<CreditCardTransaction> replyCreditQueriesMismatch(
			@PathVariable("serviceRequest") String serviceRequest) throws IBSException {

		BigInteger mismatchTransactionId = bankService.getCreditTransactionId(serviceRequest);
		CreditCardTransaction creditCardBeanTrns = bankService.getCreditMismatchTransaction(mismatchTransactionId);
		return new ResponseEntity<CreditCardTransaction>(creditCardBeanTrns, HttpStatus.OK);

	}

	@PutMapping("/mismatchDebitBlock/{cardNum}/{answer}")
	public ResponseEntity<String> replyQueriesDebit(@PathVariable("cardNum") BigInteger debitCardNumber,@PathVariable("answer") String answer) throws IBSException {
		 if(answer.equalsIgnoreCase("Yes")) {
		bankService.blockDebit(debitCardNumber);

		String output = "You card has been blocked successfully.";
		return new ResponseEntity<String>(output, HttpStatus.OK);
		 }
		 else {
        	 String output = "You have chosen no.";
 		return new ResponseEntity<String>(output, HttpStatus.OK);}

	}

	@PutMapping("/mismatchCreditBlock/{cardNum}/{answer}")
	public ResponseEntity<String> replyQueriesCredit(@PathVariable("cardNum") BigInteger creditCardNumber,@PathVariable("answer") String answer)
			throws IBSException {
         if(answer.equalsIgnoreCase("Yes")) {
		bankService.blockCredit(creditCardNumber);
		String output = "You card has been blocked successfully.";
		return new ResponseEntity<String>(output, HttpStatus.OK);
         }
         else {
        	 String output = "You have chosen no.";
 		return new ResponseEntity<String>(output, HttpStatus.OK);
	}}

	@PostMapping(value = "/replyQueries")
	public ResponseEntity<String> replyQueries(@RequestBody CaseIdBean caseIdBean) throws IBSException {

		String serviceRequest = caseIdBean.getCaseIdTotal();
		String status = caseIdBean.getStatusOfServiceRequest();
		String remarks = caseIdBean.getBankAdminRemarks();

		bankService.setQueryStatus(serviceRequest, status, remarks);
		String output = "Replied successfully to the query";
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@GetMapping(value = "/viewNewcredit")
	public ResponseEntity<List<CaseIdBean>> listNewCreditQueries() throws IBSException {
		List<CaseIdBean> caseBeans = bankService.viewNewCreditQueries();
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@GetMapping(value = "/viewUpgradeDebit")
	public ResponseEntity<List<CaseIdBean>> listNewUpgradeDebitQueries() throws IBSException {
		List<CaseIdBean>

		caseBeans = bankService.viewDebitUpgradeQueries();
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);
	}

	@GetMapping(value = "/viewUpgradeCredit")
	public ResponseEntity<List<CaseIdBean>> listNewUpgradeCreditQueries() throws IBSException {
		List<CaseIdBean> caseBeans = bankService.viewCreditUgradeQueries();
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@ExceptionHandler
	public ResponseEntity<String> ibsException(IBSException e) {

		String output = e.getMessage();
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}
}
