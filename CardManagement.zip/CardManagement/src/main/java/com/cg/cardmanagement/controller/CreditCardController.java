package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.CreditCardBean;
import com.cg.cardmanagement.model.CreditCardTransaction;
import com.cg.cardmanagement.service.CreditCustomer;
import com.cg.cardmanagement.service.CreditCustomerVerification;

@RestController
@Scope("session")
@RequestMapping("/credit")
public class CreditCardController {

	@Autowired
	private CreditCustomer creditService;
	@Autowired
	private CreditCustomerVerification creditVerify;
	List<CreditCardTransaction> trans;

	@GetMapping("/creditlist")
	public ResponseEntity<List<Object[]>> list() throws IBSException {
		//List<CreditCardBean> creditCardBeans = creditService.viewAllCreditCards();
		List<Object[]>creditCardBeansSorted = creditService.viewAllSortedCreditCards();

		return new ResponseEntity<List<Object[]>>(creditCardBeansSorted, HttpStatus.OK);
	}

	@GetMapping("/carddisplaymenu/{cardNumber}")
	public ResponseEntity<Object> cardDetails(@PathVariable("cardNumber") BigInteger cardNumber)
			throws IBSException {
		Object object = creditService.fetchCreditdetails(cardNumber);
		

		return new ResponseEntity<Object>(object, HttpStatus.OK);
	}

	@PatchMapping(value = "/block/{cardNumber}/{pin}")
	public ResponseEntity<String> block(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) throws IBSException {
		String output = "";

		if (!creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Blocked")) {
			if (creditVerify.verifyCreditPin(pin, cardNumber)) {
				creditService.requestCreditCardLost(cardNumber);
				output = " Your card has been Blocked. Contact branch for further process!";
			} else {
				output = "Card number and pin don't match!! Try again!";
			}
		} else {

			output = "Card already blocked";
		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@PatchMapping(value = "/activate/{cardNumber}/{pin}")
	public ResponseEntity<String> activate(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) throws IBSException {
		String output = "";

		if (creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
			if (creditVerify.verifyCreditPin(pin, cardNumber)) {
				creditService.activateCreditCard(cardNumber);
				output = "Card successfully activated!";
			} else {
				output = "Card number and pin don't match!! Try again!";
			}
		} else {

			
			String status=creditService.getCreditcardStatus(cardNumber);
			output = "Card already "+status;
		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@PatchMapping(value = "/deactivate/{cardNumber}/{pin}")
	public ResponseEntity<String> deactivate(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) throws IBSException {
		String output = "";

		if (creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Active")) {

			if (creditVerify.verifyCreditPin(pin, cardNumber)) {

				creditService.deactivateCreditCard(cardNumber);
				output = "Card successfully deactivated!";
			} else {
				output = "Card number and pin don't match!! Try again!";
			}
		} else {
			String status=creditService.getCreditcardStatus(cardNumber);
			output = "Card already "+status;

		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@PatchMapping(value = "/resetpin/{cardNumber}/{newpin}/{newpin2}/{pin}")
	public ResponseEntity<String> resetPin2(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("newpin") String newpin, @PathVariable("newpin2") String newpin2,
			@PathVariable("pin") String pin) throws IBSException {
		String output = "";

		if (creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Active")) {

			if (creditVerify.verifyCreditPin(pin, cardNumber)) {

				if (newpin2.equals(newpin)) {
					creditService.resetCreditPin(cardNumber, newpin);
					output = "PIN SUCCESSFULLY CHANGED";
				} else {
					output = "PINS DO NOT MATCH!! TRY AGAIN";
				}
				return new ResponseEntity<String>(output, HttpStatus.OK);
			} else {
				output = "Card number and pin don't match!! Try again!";

			}

		} else {

			output = "Your Card is Blocked . Cannot change pin!";
		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@PostMapping(value = "/upgrade")
	public ResponseEntity<String> upgrade(@RequestBody CaseIdBean caseIdBean) throws IBSException {

		String type = caseIdBean.getDefineServiceRequest();
		BigInteger cardNumber = caseIdBean.getCardNumber();
		String remarks = caseIdBean.getCustomerRemarks();

		String output = "";

		if (creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Active")) {

			String initialType = creditService.getCreditcardType(cardNumber);
			if (initialType.equalsIgnoreCase("Silver")) {
				if (type.equalsIgnoreCase("Gold") || type.equalsIgnoreCase("Platinum")) {
					String num = creditService.requestCreditCardUpgrade(cardNumber, type, remarks);
					output = "Ticket Raised successfully. Your reference Id is" + num;

				} else {

					output = "you can only upgrade to Gold/platinum";
				}

			} else

			if (initialType.equalsIgnoreCase("Gold")) {

				if (type.equalsIgnoreCase("Platinum")) {
					String num = creditService.requestCreditCardUpgrade(cardNumber, type, remarks);
					output = "Ticket Raised successfully. Your reference Id is" + num;

				} else {

					output = "you can only upgrade to Platinum";
				}

			}

			else

			if (initialType.equalsIgnoreCase("Platinum")) {

				output = "Highest level .Cannot upgrade any further";

			} else {

				output = "Invalid Card Type";
			}

		} else {
			output = "Cannot upgrade Inactive or Blocked card";
		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@GetMapping(value = "/requestStatement/{cardNumber}/{fromdate}/{enddate}")
	public ResponseEntity<List<CreditCardTransaction>> requestStatement(

			@PathVariable("cardNumber") BigInteger cardNumber, @PathVariable("fromdate") String fromdate,
			@PathVariable("enddate") String enddate) throws IBSException {

		DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;

		LocalDate startDate1 = LocalDate.parse(fromdate, formatter);
		LocalDate endDate1 = LocalDate.parse(enddate, formatter);
		List<CreditCardTransaction> bean1 = creditService.getCreditTrans(startDate1, endDate1, cardNumber);
		return new ResponseEntity<List<CreditCardTransaction>>(bean1, HttpStatus.OK);

	}

	@GetMapping(value = "/mismatchCredit/{transactionId}/{remarks}")
	public ResponseEntity<String> creditMismatch(@PathVariable("transactionId") BigInteger transactionId,
			@PathVariable("remarks") String remarks) throws IBSException {

		String refId = creditService.raiseCreditMismatchTicket(transactionId, remarks);
		String output = " Ticket raised successfully. your reference ID is " + refId;
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@GetMapping(value = "/applynewcredit/{uci}/{type}")
	public ResponseEntity<String> applyNewCreditCard2(@PathVariable("uci") BigInteger uci,
			@PathVariable("type") String type) throws IBSException {
		String output = "";

		if (creditService.checkCreditCardCount()) {

			String num = creditService.applyNewCreditCard(type, uci);
			output = "Ticket Raised successfully. Your reference Id is" + num;
		} else {
			output = "You already have 1 active credit card";

		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@ExceptionHandler
	public ResponseEntity<String> ibsException(IBSException e) {

		String output = e.getMessage();
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}
}
