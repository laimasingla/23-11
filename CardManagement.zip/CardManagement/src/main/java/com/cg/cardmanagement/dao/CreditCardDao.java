package com.cg.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CreditCardBean;

public interface CreditCardDao {

	List<CreditCardBean> viewAllCreditCards() throws IBSException;

	String getCreditCardPin(BigInteger creditCardNumber) throws IBSException;

	BigInteger getCreditUci(BigInteger creditCardNumber) throws IBSException;

	String getcreditCardType(BigInteger creditCardNumber) throws IBSException;

	String getCreditCardStatus(BigInteger creditCardNumber) throws IBSException;

	void setNewCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException;

	void actionUpgradeCC(String queryId) throws IBSException;

//	boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException;

	void actionANCC(CreditCardBean bean1) throws IBSException;

	// void actionBlockCC(String queryId, String status) throws IBSException;

	void blockCreditCard(BigInteger creditCardNumber) throws IBSException;

	List<CreditCardBean> viewAllUnblockedCreditCards() throws IBSException;

	void deactivateCreditCard(BigInteger creditCardNumber) throws IBSException;

	void activateCreditCard(BigInteger creditCardNumber) throws IBSException;

	List<CreditCardBean> viewAllInactiveCreditCards() throws IBSException;

	Object getCreditdetails(BigInteger creditCard) throws IBSException;

	boolean checkBlocked(BigInteger creditCardNumber)throws IBSException;

	List<Object[]> viewAllSortedCreditCards() throws IBSException;

}
