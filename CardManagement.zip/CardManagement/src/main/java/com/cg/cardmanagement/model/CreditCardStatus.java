package com.cg.cardmanagement.model;

public enum CreditCardStatus {

		 APPROVED, DECLINED, PENDING, BLOCKED
		
}
